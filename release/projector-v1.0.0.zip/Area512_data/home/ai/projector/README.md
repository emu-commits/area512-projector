PROJECTOR - play your ideas forward

1. n: a new idea. Answer one line per screen:
   name, wish, proof, why, how far ahead, money now, then stages.
2. The strip shows your stages. ! marks a crack.
3. p plays it forward as a film. It stops where it
   breaks: f face it, a accept the cost, e fix it.
4. c lists the cracks. Fix each one in the plan,
   or face it: "If it happens, I will ...".
   Money cracks can also be accepted: where the
   money comes from, and why it's worth it.
5. o: premortem. "It didn't work out. Why?"
6. When nothing is left open, the projection HOLDS.

Tab opens the menu bar on every list: every command,
with its key. Tab > Help lists them all. One key at a
time: ; . , / are the arrows, ` is Esc (back).

Keys on the strip
  , / or h/l stage   p play   c cracks   m money
  e edit     n new       x delete  v vision
  a assumptions          o obstacle
  w notes   b money sheet
  s save    Tab menu    Esc back

w opens the idea's notes in Writer (one document an
idea, "<title> notes"). b writes the plan's money as
a sheet in Calc ("<title> money": a row a stage, the
nets and totals as formulas, the likely end), asking
first if there's one already. Both save first.

Switching apps (Tab, then the app's digit) saves first
and comes back to the same idea and stage. Leaving with
Esc asks before it saves.

Numbers: 5k = 5000. Each stage: one-time spend,
costs a month, income a month. Fixed costs
(m money, f) come on top of every stage.
Sure / rough / guess widens the best and worst cases.
Hard stages run longer in the worst case.
